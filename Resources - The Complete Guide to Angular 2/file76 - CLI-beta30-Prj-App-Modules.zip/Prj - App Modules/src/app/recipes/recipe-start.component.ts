import { Component } from '@angular/core';

@Component({
  selector: 'rb-recipe-start',
  template: `
    <h1>Please select a Recipe</h1>
  `,
  styles: []
})
export class RecipeStartComponent {
}
