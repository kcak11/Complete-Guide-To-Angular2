import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fa-other',
  templateUrl: './other.component.html'
})
export class OtherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
