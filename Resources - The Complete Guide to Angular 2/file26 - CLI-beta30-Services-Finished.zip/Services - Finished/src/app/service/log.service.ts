export class LogService {
  writeToLog(logMessage: string) {
      console.log(logMessage);
  }
}
