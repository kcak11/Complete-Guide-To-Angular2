export { ServiceComponent } from './service.component';
export { CmpAComponent } from './cmp-a.component';
export { CmpBComponent } from './cmp-b.component';