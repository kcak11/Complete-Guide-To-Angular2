import { Component } from '@angular/core';

@Component({
  selector: 'rb-recipes',
  templateUrl: 'recipes.component.html'
})
export class RecipesComponent{
}
