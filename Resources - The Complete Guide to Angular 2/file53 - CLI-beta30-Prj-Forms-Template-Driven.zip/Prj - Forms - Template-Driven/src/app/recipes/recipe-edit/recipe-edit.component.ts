import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rb-recipe-edit',
  templateUrl: 'recipe-edit.component.html',
  styles: []
})
export class RecipeEditComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
