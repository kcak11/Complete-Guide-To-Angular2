import { Component } from '@angular/core';

@Component({
    selector: 'app-user-edit',
    template: `
        <h3>User Edit</h3>
    `
})
export class UserEditComponent {
}
