import { Component, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-user-component',
  template: `
      <h1>User Component</h1>
    `
})
export class UserComponent {
}
