import { Component } from '@angular/core';

@Component({
    selector: 'si-service',
    template: `
    <si-cmp-a></si-cmp-a>
    <si-cmp-b></si-cmp-b>
  `
})
export class ServiceComponent {
}
